import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/db/app_database.dart';
import 'features/reminders/services/notification_service.dart';
import 'app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Init local DB
  await AppDatabase.instance.database;

  // Init notifications (timezone + local plugin)
  await NotificationService.instance.init();

  runApp(const ProviderScope(child: BirthdayPulseApp()));
}
