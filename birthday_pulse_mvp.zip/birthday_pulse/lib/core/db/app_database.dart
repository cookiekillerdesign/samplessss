import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'birthday_pulse.db');

    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE contacts (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            photo_path TEXT,
            phone TEXT,
            relation TEXT NOT NULL,
            notes TEXT,
            interests TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE events (
            id TEXT PRIMARY KEY,
            contact_id TEXT NOT NULL,
            type TEXT NOT NULL,
            date TEXT NOT NULL,
            has_year INTEGER NOT NULL,
            title TEXT,
            FOREIGN KEY (contact_id) REFERENCES contacts (id) ON DELETE CASCADE
          )
        ''');

        await db.execute('''
          CREATE TABLE reminders (
            id TEXT PRIMARY KEY,
            event_id TEXT NOT NULL,
            offset_days INTEGER NOT NULL,
            time TEXT NOT NULL,
            custom_message TEXT,
            is_enabled INTEGER NOT NULL,
            FOREIGN KEY (event_id) REFERENCES events (id) ON DELETE CASCADE
          )
        ''');

        await db.execute('''
          CREATE TABLE gift_records (
            id TEXT PRIMARY KEY,
            contact_id TEXT NOT NULL,
            event_year INTEGER NOT NULL,
            gift_description TEXT,
            budget REAL,
            is_wishlist INTEGER NOT NULL,
            FOREIGN KEY (contact_id) REFERENCES contacts (id) ON DELETE CASCADE
          )
        ''');
      },
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }
}
