import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../features/contacts/repository/contact_repository.dart';
import '../features/reminders/repository/reminder_repository.dart';
import '../features/reminders/services/notification_service.dart';

final contactRepositoryProvider = Provider<ContactRepository>((ref) => ContactRepository());
final reminderRepositoryProvider = Provider<ReminderRepository>((ref) => ReminderRepository());
final notificationServiceProvider = Provider<NotificationService>((ref) => NotificationService.instance);

/// Список ближайших событий (для экрана "Сегодня")
final upcomingEventsProvider = FutureProvider.autoDispose<List<ContactWithEvents>>((ref) async {
  final repo = ref.watch(contactRepositoryProvider);
  return repo.getUpcoming(withinDays: 90);
});

/// Полный список контактов (для экрана "Контакты")
final allContactsProvider = FutureProvider.autoDispose((ref) async {
  final repo = ref.watch(contactRepositoryProvider);
  return repo.getAllContacts();
});
