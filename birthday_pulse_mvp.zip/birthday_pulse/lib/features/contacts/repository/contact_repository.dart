import 'package:uuid/uuid.dart';
import '../../../core/db/app_database.dart';
import '../models/contact_model.dart';
import '../models/event_model.dart';

class ContactWithEvents {
  final ContactModel contact;
  final List<EventModel> events;
  ContactWithEvents(this.contact, this.events);
}

class ContactRepository {
  final _uuid = const Uuid();

  Future<String> addContact(ContactModel contact) async {
    final db = await AppDatabase.instance.database;
    await db.insert('contacts', contact.toMap());
    return contact.id;
  }

  Future<void> updateContact(ContactModel contact) async {
    final db = await AppDatabase.instance.database;
    await db.update('contacts', contact.toMap(), where: 'id = ?', whereArgs: [contact.id]);
  }

  Future<void> deleteContact(String id) async {
    final db = await AppDatabase.instance.database;
    await db.delete('contacts', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<ContactModel>> getAllContacts() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('contacts', orderBy: 'name COLLATE NOCASE ASC');
    return rows.map(ContactModel.fromMap).toList();
  }

  Future<String> addEvent(EventModel event) async {
    final db = await AppDatabase.instance.database;
    await db.insert('events', event.toMap());
    return event.id;
  }

  Future<void> deleteEvent(String id) async {
    final db = await AppDatabase.instance.database;
    await db.delete('events', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<EventModel>> getEventsForContact(String contactId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('events', where: 'contact_id = ?', whereArgs: [contactId]);
    return rows.map(EventModel.fromMap).toList();
  }

  /// Все события со связанными контактами, отсортированные по ближайшей дате наступления
  Future<List<ContactWithEvents>> getUpcoming({int withinDays = 90}) async {
    final db = await AppDatabase.instance.database;
    final contactRows = await db.query('contacts');
    final contacts = {for (final c in contactRows) c['id'] as String: ContactModel.fromMap(c)};

    final eventRows = await db.query('events');
    final events = eventRows.map(EventModel.fromMap).toList();

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    final result = <ContactWithEvents>[];
    for (final e in events) {
      final next = e.nextOccurrence(today);
      final daysUntil = next.difference(today).inDays;
      if (daysUntil <= withinDays) {
        final contact = contacts[e.contactId];
        if (contact != null) {
          result.add(ContactWithEvents(contact, [e]));
        }
      }
    }

    result.sort((a, b) {
      final da = a.events.first.nextOccurrence(today);
      final db_ = b.events.first.nextOccurrence(today);
      return da.compareTo(db_);
    });

    return result;
  }

  String newId() => _uuid.v4();
}
