enum RelationType { family, friend, colleague, other }

class ContactModel {
  final String id;
  final String name;
  final String? photoPath;
  final String? phone;
  final RelationType relation;
  final String? notes;
  final String? interests; // comma-separated, для будущего AI-модуля

  ContactModel({
    required this.id,
    required this.name,
    this.photoPath,
    this.phone,
    this.relation = RelationType.other,
    this.notes,
    this.interests,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'photo_path': photoPath,
        'phone': phone,
        'relation': relation.name,
        'notes': notes,
        'interests': interests,
      };

  factory ContactModel.fromMap(Map<String, dynamic> map) => ContactModel(
        id: map['id'] as String,
        name: map['name'] as String,
        photoPath: map['photo_path'] as String?,
        phone: map['phone'] as String?,
        relation: RelationType.values.firstWhere(
          (r) => r.name == map['relation'],
          orElse: () => RelationType.other,
        ),
        notes: map['notes'] as String?,
        interests: map['interests'] as String?,
      );

  ContactModel copyWith({
    String? name,
    String? photoPath,
    String? phone,
    RelationType? relation,
    String? notes,
    String? interests,
  }) {
    return ContactModel(
      id: id,
      name: name ?? this.name,
      photoPath: photoPath ?? this.photoPath,
      phone: phone ?? this.phone,
      relation: relation ?? this.relation,
      notes: notes ?? this.notes,
      interests: interests ?? this.interests,
    );
  }
}
