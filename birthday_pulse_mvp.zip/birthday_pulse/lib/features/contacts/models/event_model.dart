enum EventType { birthday, anniversary, custom }

class EventModel {
  final String id;
  final String contactId;
  final EventType type;
  final DateTime date; // хранится с реальным годом; hasYear говорит, учитывать ли его
  final bool hasYear;
  final String? title; // для custom-событий

  EventModel({
    required this.id,
    required this.contactId,
    required this.type,
    required this.date,
    this.hasYear = true,
    this.title,
  });

  /// Ближайшая дата наступления события от [from] (учитывает перенос на следующий год)
  DateTime nextOccurrence(DateTime from) {
    var next = DateTime(from.year, date.month, date.day);
    if (next.isBefore(DateTime(from.year, from.month, from.day))) {
      next = DateTime(from.year + 1, date.month, date.day);
    }
    return next;
  }

  int? ageOn(DateTime from) {
    if (!hasYear) return null;
    final next = nextOccurrence(from);
    return next.year - date.year;
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'contact_id': contactId,
        'type': type.name,
        'date': date.toIso8601String(),
        'has_year': hasYear ? 1 : 0,
        'title': title,
      };

  factory EventModel.fromMap(Map<String, dynamic> map) => EventModel(
        id: map['id'] as String,
        contactId: map['contact_id'] as String,
        type: EventType.values.firstWhere(
          (t) => t.name == map['type'],
          orElse: () => EventType.birthday,
        ),
        date: DateTime.parse(map['date'] as String),
        hasYear: (map['has_year'] as int) == 1,
        title: map['title'] as String?,
      );
}
