import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers.dart';
import 'add_edit_contact_screen.dart';
import 'import_contacts_screen.dart';

class ContactsListScreen extends ConsumerWidget {
  const ContactsListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final contactsAsync = ref.watch(allContactsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Контакты'),
        actions: [
          IconButton(
            icon: const Icon(Icons.contact_page_outlined),
            tooltip: 'Импорт из телефона',
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ImportContactsScreen()),
              );
              ref.invalidate(allContactsProvider);
              ref.invalidate(upcomingEventsProvider);
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const AddEditContactScreen()),
          );
          ref.invalidate(allContactsProvider);
          ref.invalidate(upcomingEventsProvider);
        },
        child: const Icon(Icons.add),
      ),
      body: contactsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('Ошибка: $e')),
        data: (contacts) {
          if (contacts.isEmpty) {
            return const Center(child: Text('Список контактов пуст'));
          }
          return ListView.builder(
            itemCount: contacts.length,
            itemBuilder: (context, i) {
              final c = contacts[i];
              return ListTile(
                leading: CircleAvatar(child: Text(c.name.isNotEmpty ? c.name[0].toUpperCase() : '?')),
                title: Text(c.name),
                subtitle: Text(_relationLabel(c.relation)),
                onTap: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => AddEditContactScreen(existing: c)),
                  );
                  ref.invalidate(allContactsProvider);
                  ref.invalidate(upcomingEventsProvider);
                },
              );
            },
          );
        },
      ),
    );
  }

  String _relationLabel(dynamic relation) {
    switch (relation.toString().split('.').last) {
      case 'family':
        return 'Семья';
      case 'friend':
        return 'Друг';
      case 'colleague':
        return 'Коллега';
      default:
        return 'Другое';
    }
  }
}
