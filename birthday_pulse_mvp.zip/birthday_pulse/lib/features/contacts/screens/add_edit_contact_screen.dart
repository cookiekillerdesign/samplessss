import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers.dart';
import '../models/contact_model.dart';
import '../models/event_model.dart';

class AddEditContactScreen extends ConsumerStatefulWidget {
  final ContactModel? existing;
  const AddEditContactScreen({super.key, this.existing});

  @override
  ConsumerState<AddEditContactScreen> createState() => _AddEditContactScreenState();
}

class _AddEditContactScreenState extends ConsumerState<AddEditContactScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _notesCtrl;
  RelationType _relation = RelationType.friend;
  DateTime? _birthDate;
  bool _hasYear = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _nameCtrl = TextEditingController(text: e?.name ?? '');
    _phoneCtrl = TextEditingController(text: e?.phone ?? '');
    _notesCtrl = TextEditingController(text: e?.notes ?? '');
    _relation = e?.relation ?? RelationType.friend;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _birthDate ?? DateTime(now.year - 25, now.month, now.day),
      firstDate: DateTime(1900),
      lastDate: now,
      helpText: 'Дата рождения',
    );
    if (picked != null) setState(() => _birthDate = picked);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_birthDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Укажите дату рождения')),
      );
      return;
    }

    setState(() => _saving = true);

    final contactRepo = ref.read(contactRepositoryProvider);
    final reminderRepo = ref.read(reminderRepositoryProvider);
    final notificationService = ref.read(notificationServiceProvider);

    final isEdit = widget.existing != null;
    final contact = ContactModel(
      id: isEdit ? widget.existing!.id : contactRepo.newId(),
      name: _nameCtrl.text.trim(),
      phone: _phoneCtrl.text.trim().isEmpty ? null : _phoneCtrl.text.trim(),
      relation: _relation,
      notes: _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim(),
    );

    if (isEdit) {
      await contactRepo.updateContact(contact);
    } else {
      await contactRepo.addContact(contact);
    }

    // MVP: одно основное событие "день рождения" на контакт.
    // Более сложный сценарий (несколько событий) добавляется в v1.5.
    final existingEvents = await contactRepo.getEventsForContact(contact.id);
    String eventId;
    if (existingEvents.isNotEmpty) {
      eventId = existingEvents.first.id;
      await contactRepo.deleteEvent(eventId); // пересоздаём с новой датой
    }
    eventId = contactRepo.newId();
    final event = EventModel(
      id: eventId,
      contactId: contact.id,
      type: EventType.birthday,
      date: _birthDate!,
      hasYear: _hasYear,
    );
    await contactRepo.addEvent(event);

    // Создаём дефолтные напоминания (7 дней / 1 день / в день) и планируем уведомления
    await reminderRepo.createDefaultRemindersForEvent(eventId);
    final reminders = await reminderRepo.getRemindersForEvent(eventId);
    for (final r in reminders) {
      await notificationService.scheduleReminder(reminder: r, event: event, contact: contact);
    }

    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Редактировать контакт' : 'Новый контакт')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Имя'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Обязательное поле' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _phoneCtrl,
              decoration: const InputDecoration(labelText: 'Телефон (опционально)'),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(_birthDate == null
                  ? 'Дата рождения не выбрана'
                  : 'Дата: ${_birthDate!.day}.${_birthDate!.month}.${_birthDate!.year}'),
              trailing: const Icon(Icons.calendar_today_outlined),
              onTap: _pickDate,
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Год рождения известен'),
              subtitle: const Text('Влияет на расчёт возраста в уведомлениях'),
              value: _hasYear,
              onChanged: (v) => setState(() => _hasYear = v),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<RelationType>(
              initialValue: _relation,
              decoration: const InputDecoration(labelText: 'Тип отношений'),
              items: const [
                DropdownMenuItem(value: RelationType.family, child: Text('Семья')),
                DropdownMenuItem(value: RelationType.friend, child: Text('Друг')),
                DropdownMenuItem(value: RelationType.colleague, child: Text('Коллега')),
                DropdownMenuItem(value: RelationType.other, child: Text('Другое')),
              ],
              onChanged: (v) => setState(() => _relation = v ?? RelationType.other),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _notesCtrl,
              decoration: const InputDecoration(labelText: 'Заметки (опционально)'),
              maxLines: 3,
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _saving ? null : _save,
              child: _saving
                  ? const SizedBox(
                      height: 20, width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Сохранить'),
            ),
          ],
        ),
      ),
    );
  }
}
