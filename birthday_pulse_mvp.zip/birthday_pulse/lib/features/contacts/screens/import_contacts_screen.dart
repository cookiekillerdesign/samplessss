import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart' as fc;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers.dart';
import '../models/contact_model.dart';
import '../models/event_model.dart';

class ImportContactsScreen extends ConsumerStatefulWidget {
  const ImportContactsScreen({super.key});

  @override
  ConsumerState<ImportContactsScreen> createState() => _ImportContactsScreenState();
}

class _ImportContactsScreenState extends ConsumerState<ImportContactsScreen> {
  bool _loading = true;
  List<fc.Contact> _deviceContacts = [];
  final Set<String> _selectedIds = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final granted = await fc.FlutterContacts.requestPermission();
    if (!granted) {
      setState(() => _loading = false);
      return;
    }
    final all = await fc.FlutterContacts.getContacts(
      withProperties: true,
      withPhoto: false,
    );
    // Оставляем только контакты с датой рождения — иначе импорт бессмыслен для этого приложения
    final withBirthday = all.where((c) => c.events.any((e) => e.label == fc.EventLabel.birthday)).toList();

    setState(() {
      _deviceContacts = withBirthday;
      _loading = false;
    });
  }

  DateTime? _birthdayOf(fc.Contact c) {
    final ev = c.events.firstWhere(
      (e) => e.label == fc.EventLabel.birthday,
      orElse: () => fc.Event(),
    );
    if (ev.year == null && ev.month == null) return null;
    return DateTime(ev.year ?? 1900, ev.month ?? 1, ev.day ?? 1);
  }

  Future<void> _importSelected() async {
    final contactRepo = ref.read(contactRepositoryProvider);
    final reminderRepo = ref.read(reminderRepositoryProvider);
    final notificationService = ref.read(notificationServiceProvider);

    for (final c in _deviceContacts.where((c) => _selectedIds.contains(c.id))) {
      final birthday = _birthdayOf(c);
      if (birthday == null) continue;

      final ev = c.events.firstWhere((e) => e.label == fc.EventLabel.birthday);
      final hasYear = ev.year != null;

      final contact = ContactModel(
        id: contactRepo.newId(),
        name: c.displayName,
        phone: c.phones.isNotEmpty ? c.phones.first.number : null,
      );
      await contactRepo.addContact(contact);

      final eventId = contactRepo.newId();
      final event = EventModel(
        id: eventId,
        contactId: contact.id,
        type: EventType.birthday,
        date: birthday,
        hasYear: hasYear,
      );
      await contactRepo.addEvent(event);

      await reminderRepo.createDefaultRemindersForEvent(eventId);
      final reminders = await reminderRepo.getRemindersForEvent(eventId);
      for (final r in reminders) {
        await notificationService.scheduleReminder(reminder: r, event: event, contact: contact);
      }
    }

    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Импорт контактов'),
        actions: [
          if (_selectedIds.isNotEmpty)
            TextButton(
              onPressed: _importSelected,
              child: Text('Импортировать (${_selectedIds.length})'),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _deviceContacts.isEmpty
              ? const Center(child: Text('Не найдено контактов с датой рождения'))
              : ListView.builder(
                  itemCount: _deviceContacts.length,
                  itemBuilder: (context, i) {
                    final c = _deviceContacts[i];
                    final selected = _selectedIds.contains(c.id);
                    final bday = _birthdayOf(c);
                    return CheckboxListTile(
                      value: selected,
                      onChanged: (v) {
                        setState(() {
                          if (v == true) {
                            _selectedIds.add(c.id);
                          } else {
                            _selectedIds.remove(c.id);
                          }
                        });
                      },
                      title: Text(c.displayName),
                      subtitle: Text(bday != null ? '${bday.day}.${bday.month}.${bday.year}' : ''),
                    );
                  },
                ),
    );
  }
}
