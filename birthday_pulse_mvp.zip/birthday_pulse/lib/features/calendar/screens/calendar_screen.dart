import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../../core/providers.dart';
import '../../contacts/repository/contact_repository.dart';

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  Widget build(BuildContext context) {
    final upcomingAsync = ref.watch(upcomingEventsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Календарь')),
      body: upcomingAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('Ошибка: $e')),
        data: (items) {
          final eventsByDay = <DateTime, List<ContactWithEvents>>{};
          final now = DateTime.now();
          final today = DateTime(now.year, now.month, now.day);

          for (final item in items) {
            final next = item.events.first.nextOccurrence(today);
            final key = DateTime(next.year, next.month, next.day);
            eventsByDay.putIfAbsent(key, () => []).add(item);
          }

          final selectedEvents = _selectedDay != null
              ? (eventsByDay[DateTime(_selectedDay!.year, _selectedDay!.month, _selectedDay!.day)] ?? [])
              : <ContactWithEvents>[];

          return Column(
            children: [
              TableCalendar(
                firstDay: DateTime(now.year - 1),
                lastDay: DateTime(now.year + 5),
                focusedDay: _focusedDay,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                onDaySelected: (selected, focused) {
                  setState(() {
                    _selectedDay = selected;
                    _focusedDay = focused;
                  });
                },
                eventLoader: (day) => eventsByDay[DateTime(day.year, day.month, day.day)] ?? [],
                calendarStyle: CalendarStyle(
                  markerDecoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    shape: BoxShape.circle,
                  ),
                  selectedDecoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    shape: BoxShape.circle,
                  ),
                  todayDecoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.secondaryContainer,
                    shape: BoxShape.circle,
                  ),
                ),
                headerStyle: const HeaderStyle(formatButtonVisible: false, titleCentered: true),
              ),
              const Divider(height: 1),
              Expanded(
                child: selectedEvents.isEmpty
                    ? const Center(child: Text('Нет событий в этот день'))
                    : ListView.builder(
                        itemCount: selectedEvents.length,
                        itemBuilder: (context, i) {
                          final c = selectedEvents[i].contact;
                          return ListTile(
                            leading: const Icon(Icons.cake_outlined),
                            title: Text(c.name),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
