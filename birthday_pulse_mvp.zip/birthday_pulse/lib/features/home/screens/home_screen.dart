import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers.dart';
import '../../contacts/repository/contact_repository.dart';
import '../../contacts/models/event_model.dart';
import '../../contacts/screens/add_edit_contact_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final upcomingAsync = ref.watch(upcomingEventsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Ближайшие события')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const AddEditContactScreen()),
          );
          ref.invalidate(upcomingEventsProvider);
        },
        icon: const Icon(Icons.add),
        label: const Text('Добавить'),
      ),
      body: upcomingAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('Ошибка: $e')),
        data: (items) {
          if (items.isEmpty) {
            return _EmptyState();
          }

          final now = DateTime.now();
          final today = DateTime(now.year, now.month, now.day);

          final todayItems = <ContactWithEvents>[];
          final weekItems = <ContactWithEvents>[];
          final monthItems = <ContactWithEvents>[];
          final laterItems = <ContactWithEvents>[];

          for (final item in items) {
            final next = item.events.first.nextOccurrence(today);
            final days = next.difference(today).inDays;
            if (days == 0) {
              todayItems.add(item);
            } else if (days <= 7) {
              weekItems.add(item);
            } else if (days <= 30) {
              monthItems.add(item);
            } else {
              laterItems.add(item);
            }
          }

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (todayItems.isNotEmpty) _Section('Сегодня', todayItems, today),
              if (weekItems.isNotEmpty) _Section('На этой неделе', weekItems, today),
              if (monthItems.isNotEmpty) _Section('В этом месяце', monthItems, today),
              if (laterItems.isNotEmpty) _Section('Позже', laterItems, today),
            ],
          );
        },
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final List<ContactWithEvents> items;
  final DateTime today;

  const _Section(this.title, this.items, this.today);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 8),
          child: Text(title, style: Theme.of(context).textTheme.titleMedium),
        ),
        ...items.map((item) => _EventCard(item: item, today: today)),
      ],
    );
  }
}

class _EventCard extends StatelessWidget {
  final ContactWithEvents item;
  final DateTime today;

  const _EventCard({required this.item, required this.today});

  @override
  Widget build(BuildContext context) {
    final event = item.events.first;
    final contact = item.contact;
    final next = event.nextOccurrence(today);
    final days = next.difference(today).inDays;
    final age = event.ageOn(next);

    String subtitle;
    if (days == 0) {
      subtitle = age != null ? 'Сегодня • исполняется $age' : 'Сегодня';
    } else {
      subtitle = 'Через $days дн.${age != null ? ' • исполнится $age' : ''}';
    }

    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          radius: 22,
          child: Text(contact.name.isNotEmpty ? contact.name[0].toUpperCase() : '?'),
        ),
        title: Text(contact.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: Wrap(
          spacing: 4,
          children: [
            if (contact.phone != null)
              IconButton(
                icon: const Icon(Icons.call_outlined),
                onPressed: () {}, // интеграция с url_launcher добавляется на этапе полировки
              ),
            IconButton(
              icon: const Icon(Icons.check_circle_outline),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Отмечено как поздравлено 🎉')),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.cake_outlined, size: 64, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 16),
            Text('Пока нет ближайших событий', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            const Text(
              'Добавьте контакт с датой рождения, чтобы начать получать напоминания',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
