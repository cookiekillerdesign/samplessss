import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;
import '../../contacts/models/contact_model.dart';
import '../../contacts/models/event_model.dart';
import '../models/reminder_model.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tz_data.initializeTimeZones();

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const initSettings = InitializationSettings(android: androidInit, iOS: iosInit);

    await _plugin.initialize(initSettings);

    // Android 13+ runtime permission
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();

    // Точные напоминания на Android 12+
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestExactAlarmsPermission();
  }

  /// Планирует одно уведомление под конкретное напоминание+событие+контакт
  Future<void> scheduleReminder({
    required ReminderModel reminder,
    required EventModel event,
    required ContactModel contact,
  }) async {
    if (!reminder.isEnabled) return;

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final occurrence = event.nextOccurrence(today);
    final fireDate = occurrence.subtract(Duration(days: reminder.offsetDays));

    final timeParts = reminder.time.split(':');
    final hour = int.parse(timeParts[0]);
    final minute = int.parse(timeParts[1]);

    var scheduled = tz.TZDateTime(
      tz.local,
      fireDate.year,
      fireDate.month,
      fireDate.day,
      hour,
      minute,
    );

    // Если время уже прошло сегодня — не планируем в прошлом (пропускаем это уведомление)
    if (scheduled.isBefore(tz.TZDateTime.now(tz.local))) return;

    final age = event.ageOn(occurrence);
    final title = _buildTitle(reminder, event, contact, age);
    final body = _buildBody(reminder, event, contact, age);

    await _plugin.zonedSchedule(
      _notificationId(reminder.id),
      title,
      body,
      scheduled,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'birthday_reminders',
          'Напоминания о днях рождения',
          channelDescription: 'Уведомления о предстоящих днях рождения и событиях',
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.dateAndTime,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancelReminder(String reminderId) async {
    await _plugin.cancel(_notificationId(reminderId));
  }

  Future<void> cancelAll() async => _plugin.cancelAll();

  String _buildTitle(ReminderModel r, EventModel e, ContactModel c, int? age) {
    if (r.offsetDays == 0) return '🎉 Сегодня день рождения у ${c.name}!';
    if (r.offsetDays == 1) return 'Завтра ДР у ${c.name}';
    return 'Через ${r.offsetDays} дн. — ДР у ${c.name}';
  }

  String _buildBody(ReminderModel r, EventModel e, ContactModel c, int? age) {
    if (r.customMessage != null && r.customMessage!.isNotEmpty) {
      return _applyPlaceholders(r.customMessage!, c, age);
    }
    if (age != null) {
      return 'Исполняется $age лет. Не забудьте поздравить!';
    }
    return 'Не забудьте поздравить!';
  }

  String _applyPlaceholders(String template, ContactModel c, int? age) {
    return template
        .replaceAll('{{name}}', c.name)
        .replaceAll('{{age}}', age?.toString() ?? '')
        .replaceAll('{{relation}}', c.relation.name);
  }

  /// Стабильный числовой id уведомления на основе UUID строки напоминания
  int _notificationId(String reminderId) => reminderId.hashCode & 0x7fffffff;
}
