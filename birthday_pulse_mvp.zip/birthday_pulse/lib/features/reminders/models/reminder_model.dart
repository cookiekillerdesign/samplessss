class ReminderModel {
  final String id;
  final String eventId;
  final int offsetDays; // 0 = в день события, 1 = за день, 7 = за неделю и т.д.
  final String time; // "HH:mm"
  final String? customMessage; // поддерживает {{name}}, {{age}}, {{relation}}
  final bool isEnabled;

  ReminderModel({
    required this.id,
    required this.eventId,
    required this.offsetDays,
    this.time = '10:00',
    this.customMessage,
    this.isEnabled = true,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'event_id': eventId,
        'offset_days': offsetDays,
        'time': time,
        'custom_message': customMessage,
        'is_enabled': isEnabled ? 1 : 0,
      };

  factory ReminderModel.fromMap(Map<String, dynamic> map) => ReminderModel(
        id: map['id'] as String,
        eventId: map['event_id'] as String,
        offsetDays: map['offset_days'] as int,
        time: map['time'] as String,
        customMessage: map['custom_message'] as String?,
        isEnabled: (map['is_enabled'] as int) == 1,
      );

  /// Дефолтный набор напоминаний для нового события: за 7 дней, за 1 день, в день
  static List<int> defaultOffsets() => const [7, 1, 0];
}
