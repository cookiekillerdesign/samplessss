import 'package:uuid/uuid.dart';
import '../../../core/db/app_database.dart';
import '../models/reminder_model.dart';

class ReminderRepository {
  final _uuid = const Uuid();

  Future<String> addReminder(ReminderModel reminder) async {
    final db = await AppDatabase.instance.database;
    await db.insert('reminders', reminder.toMap());
    return reminder.id;
  }

  Future<void> updateReminder(ReminderModel reminder) async {
    final db = await AppDatabase.instance.database;
    await db.update('reminders', reminder.toMap(), where: 'id = ?', whereArgs: [reminder.id]);
  }

  Future<void> deleteReminder(String id) async {
    final db = await AppDatabase.instance.database;
    await db.delete('reminders', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<ReminderModel>> getRemindersForEvent(String eventId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('reminders', where: 'event_id = ?', whereArgs: [eventId]);
    return rows.map(ReminderModel.fromMap).toList();
  }

  Future<List<ReminderModel>> getAllReminders() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('reminders');
    return rows.map(ReminderModel.fromMap).toList();
  }

  /// Создаёт дефолтный набор напоминаний (7 дней / 1 день / в день) для нового события
  Future<void> createDefaultRemindersForEvent(String eventId) async {
    for (final offset in ReminderModel.defaultOffsets()) {
      await addReminder(ReminderModel(
        id: _uuid.v4(),
        eventId: eventId,
        offsetDays: offset,
      ));
    }
  }
}
